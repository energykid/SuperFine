SuperFine!! is a 'Vanilla++' mod - aiming to add content that fits in with vanilla's balance, but stands out on its own.

Currently, it adds 14 Jokers, 2 Spectral cards, 3 Boss Blinds, and one deck.

Feel free to join the SuperFine!! thread in the Balatro Discord to discuss or learn more about the mod!