function lerp(x, y, z)
  return x + ((y - x) * z)
end